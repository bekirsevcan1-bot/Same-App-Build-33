Usta Cepte web build paketi
dist/public içeriğini yayınlayarak veya statik hostinge yükleyerek çalıştırabilirsiniz.
